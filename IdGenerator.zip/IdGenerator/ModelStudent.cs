﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IdGenerator
{ // poco
    class ModelStudent
    {
        public String fullName { get; set; }
        public String nationalId { get; set; }
        public String DOB { get; set; }
        public String studentImagePath { get; set; }
    }
}
